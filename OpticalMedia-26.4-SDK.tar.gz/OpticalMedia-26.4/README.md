# Optical Media headers — macOS 26.4 SDK (Xcode 26.4)

Extracted optical-media (CD / DVD / BD), general SCSI MMC, and DiscRecording
sources and headers from `MacOSX26.4.sdk`. Paths below are preserved relative
to the SDK root. See `MANIFEST.txt` for the full file list with sha256 sums.

## Contents (76 files)

### DiscRecording.framework (29 headers + .tbd + module.modulemap)
High-level burning / erasing / content / CD-Text / device APIs (DR*).

### DiscRecordingUI.framework (9 headers + .tbd + module.modulemap)
AppKit panels and sessions for burn/erase setup and progress.

### IOKit.framework (user-space)
- `storage/` — CD: `IOCD{BlockStorageDevice,Media,MediaBSDClient,PartitionScheme,Types}`
- `storage/` — DVD: `IODVD{BlockStorageDevice,Media,MediaBSDClient,Types}`
- `storage/` — BD: `IOBD{BlockStorageDevice,Media,MediaBSDClient,Types}`
- `scsi/` — MMC: `IOSCSIMultimediaCommandsDevice.h`

### Kernel.framework (kernel/driver)
- `IOKit/storage/` — CD/DVD/BD `*BlockStorageDevice`, `*BlockStorageDriver`,
  `*Media`, `*MediaBSDClient`, CD `PartitionScheme`, `*Types`
- `IOKit/scsi/` — `IOSCSIMultimediaCommandsDevice.h`,
  `IOCompactDiscServices.h`, `IODVDServices.h`, `IOBDServices.h`

> Note: generic SCSI command-set headers shared by all peripherals
> (`SCSICmds_*`, `SCSITask*`, primary/block command devices) are intentionally
> excluded — only the multimedia/MMC and optical-specific pieces are included.

# Optical Media headers — macOS 26.4 SDK (Xcode 26.4)

Extracted optical-media (CD / DVD / BD), SCSI **MMC** (MultiMedia Commands),
the user-space SCSI Architecture Model headers (SCSITaskLib etc.), and the
**DiscRecording** frameworks from `MacOSX26.4.sdk`. Paths are preserved
relative to the SDK root. See `MANIFEST.txt` for the full list with sha256 sums.

## Contents (85 files)

### DiscRecording.framework (29 headers + .tbd + module.modulemap)
High-level burning / erasing / content / CD-Text / device APIs (DR*).

### DiscRecordingUI.framework (9 headers + .tbd + module.modulemap)
AppKit panels and sessions for burn/erase setup and progress.

### IOKit.framework (user-space)
- `scsi/` — full SCSI Architecture Model header set:
  - `SCSITaskLib.h`, `SCSITask.h` — the user-client lib for issuing SCSI tasks
  - `IOSCSIMultimediaCommandsDevice.h` — MMC device
  - `SCSICommandOperationCodes.h`, `SCSICommandDefinitions.h`
  - `SCSICmds_INQUIRY_Definitions.h`, `SCSICmds_MODE_Definitions.h`,
    `SCSICmds_READ_CAPACITY_Definitions.h`, `SCSICmds_REPORT_LUNS_Definitions.h`,
    `SCSICmds_REQUEST_SENSE_Defs.h`
- `storage/` — CD: `IOCD{BlockStorageDevice,Media,MediaBSDClient,PartitionScheme,Types}`
- `storage/` — DVD: `IODVD{BlockStorageDevice,Media,MediaBSDClient,Types}`
- `storage/` — BD: `IOBD{BlockStorageDevice,Media,MediaBSDClient,Types}`

### Kernel.framework (kernel/driver)
- `IOKit/storage/` — CD/DVD/BD `*BlockStorageDevice`, `*BlockStorageDriver`,
  `*Media`, `*MediaBSDClient`, CD `PartitionScheme`, `*Types`
- `IOKit/scsi/` — `IOSCSIMultimediaCommandsDevice.h`,
  `IOCompactDiscServices.h`, `IODVDServices.h`, `IOBDServices.h`

> Note: the kernel-side generic SCSI command/peripheral headers
> (`IOSCSIPrimaryCommandsDevice`, `IOSCSIBlockCommandsDevice`,
> `IOSCSIPeripheralDeviceType05`, the `spi/` parallel-interface headers, etc.)
> are not included. Ask if you want those bundled too.

# 26.4-sdk-slice-mos

A minimal **slice of the macOS 26.4 SDK** (`MacOSX26.4.sdk`) containing the
full transitive `#include` closure required to compile the
[`mos`](https://github.com/napieraj/mos) (mac-optical-state) project — the
optical-drive state tool/library that links Apple's IOKit, CoreFoundation,
DiscRecording, and DiskArbitration frameworks.

**630 SDK header files**, paths preserved relative to the SDK root
(`System/...` and `usr/include/...`). See `MANIFEST.txt` for sha256 sums and
`SLICE_NOTES.txt` for the includes that are intentionally absent (compiler
builtins, kernel-only, other-platform, and private/internal headers not
shipped in the SDK).

## How it was built

Seeded from every system `#include`/`#import` in the `mos` sources:

```
CommonCrypto/CommonDigest.h          IOKit/scsi/SCSICmds_REQUEST_SENSE_Defs.h
CoreFoundation/CoreFoundation.h      IOKit/scsi/SCSICommandOperationCodes.h
DiscRecording/DRCoreDevice.h         IOKit/scsi/SCSITaskLib.h
DiscRecording/DRCoreNotifications.h  IOKit/storage/IOCDMedia.h
DiskArbitration/DiskArbitration.h    IOKit/storage/IOMedia.h
IOKit/IOBSD.h                        IOKit/storage/IOStorageProtocolCharacteristics.h
IOKit/IOCFPlugIn.h                   dispatch/dispatch.h
IOKit/IOKitLib.h                     mach/mach_time.h
IOKit/IOMessage.h                    sys/wait.h
```

Then every header reachable from those was resolved against the SDK
(framework headers, framework umbrella re-exports, and `usr/include`) and
followed transitively until closure.

## Framework / directory breakdown

| Location | Files |
|---|---|
| usr/include | 369 |
| CoreServices.framework | 96 |
| Security.framework | 76 |
| CoreFoundation.framework | 47 |
| IOKit.framework | 19 |
| CFNetwork.framework | 12 |
| DriverKit.framework | 4 |
| DiskArbitration.framework | 4 |
| DiscRecording.framework | 3 |

> This is the *full transitive closure* (per request): it includes the
> CoreFoundation / CommonCrypto / CoreServices / Security / CFNetwork
> umbrellas pulled in through the headers above. The optical-specific
> entry points (`DRCoreDevice`, `IOCDMedia`, `SCSITaskLib`, DiskArbitration)
> are the seeds; the rest is what they transitively require.

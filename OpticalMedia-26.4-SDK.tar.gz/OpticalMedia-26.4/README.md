# Optical Media / SCSI / Storage headers — macOS 26.4 SDK (Xcode 26.4)

A comprehensive extraction from `MacOSX26.4.sdk` of everything related to
optical media (CD / DVD / BD), SCSI **MMC** (MultiMedia Commands), the SCSI
Architecture Model, the underlying block-storage stack, and the
**DiscRecording** frameworks. Paths are preserved relative to the SDK root.
See `MANIFEST.txt` for the full list with sha256 sums.

## Contents (146 files)

### DiscRecording.framework (31 files)
High-level burn / erase / content / CD-Text / device APIs (DR*), plus `.tbd`
and module map.

### DiscRecordingUI.framework (11 files)
AppKit burn/erase setup and progress panels, plus `.tbd` and module map.

### IOKit.framework — user-space (42 headers)
- `scsi/` (10) — full SCSI Architecture Model: `SCSITaskLib.h`, `SCSITask.h`,
  `IOSCSIMultimediaCommandsDevice.h`, `SCSICommandOperationCodes.h`,
  `SCSICommandDefinitions.h`, and the `SCSICmds_*` definition headers
  (INQUIRY / MODE / READ_CAPACITY / REPORT_LUNS / REQUEST_SENSE).
- `storage/` (32) — CD/DVD/BD media, BSD clients, partition scheme & types,
  plus the generic base classes they derive from (`IOMedia`, `IOStorage`,
  `IOBlockStorageDevice`, partition schemes) and `ata/`, `nvme/` subdirs
  (ATAPI is how many optical drives attach).

### Kernel.framework — kernel/driver (62 headers)
- `IOKit/scsi/` (27) — the complete in-kernel SCSI stack: MMC device,
  optical services (`IOCompactDiscServices`, `IODVDServices`, `IOBDServices`),
  primary/block/reduced command devices, peripheral device types (incl.
  Type05 = MMC), protocol interface/services, and the `spi/` parallel
  interface headers.
- `IOKit/storage/` (35) — CD/DVD/BD `*BlockStorageDevice`/`*BlockStorageDriver`/
  `*Media`/`*MediaBSDClient`/`*Types`, plus the generic storage base classes,
  partition schemes, and `ata/` (ATAPI transport).

This is intentionally the *everything* bundle: the optical-specific classes
inherit from the generic SCSI/storage base classes, so the full trees are
included to keep the set self-contained.

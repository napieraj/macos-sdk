# 26.4-sdk-slice-mos-standalone

A **self-compiling** slice of the macOS 26.4 SDK (`MacOSX26.4.sdk`) for the
[`mos`](https://github.com/napieraj/mos) (mac-optical-state) project.

This is the same 630-header transitive `#include` closure as
`26.4-sdk-slice-mos`, **plus** the canonical `.framework` bundle symlinks
(`Headers -> Versions/Current/Headers`, `Versions/Current -> A`,
`Frameworks -> Versions/Current/Frameworks`) so the directory works directly
as a clang `-isysroot`. Compiler-provided freestanding headers
(`stdarg.h`, `stddef.h`, intrinsics, etc.) come from your clang, as usual.

## Verified

Syntax-checked clean (`-fsyntax-only`) with clang against this bundle as the
only sysroot:

- the 18 system seed headers, for both `x86_64-apple-macos` and
  `arm64-apple-macos`
- **all 27 `mos` source files** (`src/*.c`) for `x86_64-apple-macos`

## Usage

```sh
tar -xzf 26.4-sdk-slice-mos-standalone.tar.gz
clang -fsyntax-only -target x86_64-apple-macos11 \
      -isysroot ./26.4-sdk-slice-mos-standalone \
      -Iinclude -fblocks src/*.c
```

For a full build/link you still need the actual framework binaries (the
SDK ships only `.tbd` stubs and this is headers only) — this bundle is for
compiling/analysis, not linking. See `MANIFEST.txt` for sha256 sums and
`SLICE_NOTES.txt` for includes intentionally absent (all compiler builtins,
kernel-only, other-platform, or private headers — none are SDK files, and
none are reached when compiling mos for a normal macOS user-space target).

## Breakdown (630 headers + framework symlinks)

| Location | Files |
|---|---|
| usr/include | 369 |
| CoreServices.framework | 96 |
| Security.framework | 76 |
| CoreFoundation.framework | 47 |
| IOKit.framework | 19 |
| CFNetwork.framework | 12 |
| DriverKit.framework | 4 |
| DiskArbitration.framework | 4 |
| DiscRecording.framework | 3 |
